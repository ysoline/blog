<?php

//Affiche les catégories qui "trient" les chapitres du livre