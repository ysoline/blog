<?php

//Affiche un billet selectionné